SYE 6308 practice submission
This ZIP contains one selected agent, not both best and last.
Use the public Arena notebook to inspect and test the exact ZIP in a clean session.
Do not run the training notebook to make this ZIP work.
Do not replace agent.zip after self-check; the receipt binds its exact checksum.
Technical report/course deliverables are separate. No extra ROM, .state cache, credential store or videos are collected; review your selected source for secrets.
Static packaging is not model execution, a sandbox, or an official competition score.
